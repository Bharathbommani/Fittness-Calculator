# images and videos
![Capture](https://user-images.githubusercontent.com/36398260/114543285-a435df00-9c76-11eb-8f5d-3ce8834f9a48.PNG)
![maths2](https://user-images.githubusercontent.com/36398260/114543291-a5670c00-9c76-11eb-88f5-db38fb110915.jpg)
![swot analysis](https://user-images.githubusercontent.com/36398260/114543294-a5ffa280-9c76-11eb-9960-878c54b6b5ca.png)
![0001](https://user-images.githubusercontent.com/36398260/114543296-a6983900-9c76-11eb-908d-215eddc1c767.jpg)
![Untitled](https://user-images.githubusercontent.com/36398260/114543321-ac8e1a00-9c76-11eb-9610-ffdd5f9fc340.png)
![scientific_sequence](https://user-images.githubusercontent.com/36398260/114543323-ad26b080-9c76-11eb-8ed6-f20dbc43015d.png)
![arthemetic_sequence](https://user-images.githubusercontent.com/36398260/114543325-adbf4700-9c76-11eb-847d-99d31b3ba031.png)
