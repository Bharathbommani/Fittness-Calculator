# Design

## High Level Design 


- Behavioral diagram

<kbd> <img src="https://user-images.githubusercontent.com/36398260/114337727-49fe2680-9b6f-11eb-9471-2fe03dba9259.jpg" width="700" height="700"   /> </kbd>




## Low Level Design 

- Arthimetic operations behavioral diagram


![arthemetic_sequence](https://user-images.githubusercontent.com/36398260/114346929-d31e5900-9b81-11eb-8588-0957d6275a13.png)



- Scientific operations behavioral diagram

![scientific_sequence](https://user-images.githubusercontent.com/36398260/114346702-83d82880-9b81-11eb-89c9-3e607de7fe24.png)


- Trigonometric operations behavioral diagram


![Untitled](https://user-images.githubusercontent.com/36398260/114346648-70c55880-9b81-11eb-87d0-772bee521388.png)


